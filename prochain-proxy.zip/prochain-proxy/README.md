# ProChain Proxy Server

Angel One REST + WebSocket bridge for ProChain.

**Kya karta hai:**
- `POST/GET /angel/*` → Angel One REST API forward karta hai (CORS bypass)
- `wss://your-proxy/ws` → Angel One SmartStream bridge karta hai

---

## Railway Deploy (5 min)

### Step 1 — GitHub pe push karo

```bash
git init
git add .
git commit -m "ProChain proxy v1"
git remote add origin https://github.com/YOUR_USERNAME/prochain-proxy.git
git push -u origin main
```

### Step 2 — Railway

1. [railway.app](https://railway.app) → **New Project → Deploy from GitHub**
2. Repo select karo
3. **Variables** tab mein set karo:
   ```
   PROXY_SECRET = koi_bhi_secret_string
   ```
4. Deploy hone do — Railway `PORT` auto-set karta hai

### Step 3 — Railway URL copy karo

Settings → Domains → `https://prochain-proxy-production-xxxx.up.railway.app`

### Step 4 — ProChain mein set karo

ProChain Settings tab mein:
```
Proxy Base URL  = https://prochain-proxy-production-xxxx.up.railway.app
Proxy Secret    = (same jo Railway mein dala)
```

---

## Local Test

```bash
cp .env.example .env
# .env mein PROXY_SECRET set karo (optional)

npm install
npm start
# → Server on http://localhost:3000
```

Health check:
```
curl http://localhost:3000/health
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Railway auto-set karta hai |
| `PROXY_SECRET` | (empty) | Optional auth key — ProChain mein bhi same set karo |
| `ANGEL_WS_URL` | `wss://smartstream.angelbroking.com/ws/v2` | Angel One WS URL |

---

## REST Routes

| ProChain calls | Forwards to |
|---|---|
| `POST /angel/login` | Angel One login |
| `GET /angel/profile` | Profile |
| `GET /angel/order/book` | Order book |
| `POST /angel/order/place` | Place order |
| `POST /angel/quote` | LTP/quote |
| `POST /angel/historical` | Candle data |
| `POST /angel/optionchain` | Options chain |
| `GET /angel/scripmaster/:exchange` | Symbol master |
| ... sab routes | See `server.js` ANGEL_ROUTE_MAP |

## WebSocket

ProChain connects to: `wss://your-proxy.railway.app/ws`

Secret chahiye toh: `wss://your-proxy.railway.app/ws?secret=YOUR_SECRET`

Proxy transparently bridge karta hai ProChain ↔ Angel SmartStream — binary + text dono frames.
