/**
 * ProChain Proxy Server
 * ─────────────────────────────────────────────────────────────────────────────
 * Two jobs:
 *  1. REST proxy  — forwards ProChain → Angel One REST API calls
 *     (bypasses browser CORS restrictions)
 *  2. WebSocket bridge — proxies ProChain ↔ Angel One SmartStream WS
 *     (browser cant connect directly to Angel One WS due to CORS/protocol)
 *
 * Deploy on Railway:
 *   - Connect this GitHub repo
 *   - Set PROXY_SECRET env var (same in ProChain Settings)
 *   - Railway auto-assigns PORT
 *
 * ProChain Settings:
 *   PROXY_BASE = https://your-app.up.railway.app
 *   PROXY_SECRET = (same as server env)
 * ─────────────────────────────────────────────────────────────────────────────
 */

require("dotenv").config();

const express    = require("express");
const cors       = require("cors");
const http       = require("http");
const WebSocket  = require("ws");
const fetch      = require("node-fetch");
const https      = require("https");

// ─── Config ──────────────────────────────────────────────────────────────────
const PORT          = parseInt(process.env.PORT) || 3000;
const PROXY_SECRET  = process.env.PROXY_SECRET || "";
const ANGEL_WS_URL  = process.env.ANGEL_WS_URL || "wss://smartstream.angelbroking.com/ws/v2";
const ANGEL_BASE    = "https://apiconnect.angelbroking.com";
const ANGEL_DATA    = "https://margincalculator.angelbroking.com";

// ─── App ─────────────────────────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);

app.use(cors({ origin: "*" }));
app.use(express.json({ limit: "2mb" }));

// ─── Logger ──────────────────────────────────────────────────────────────────
const log  = (...a) => console.log (`[${ts()}]`, ...a);
const warn = (...a) => console.warn(`[${ts()}]`, ...a);
const err  = (...a) => console.error(`[${ts()}]`, ...a);
const ts   = ()     => new Date().toISOString();

// ─── Auth middleware (optional PROXY_SECRET) ──────────────────────────────────
function checkSecret(req, res, next) {
  if (!PROXY_SECRET) return next(); // secret not configured → open proxy
  const sent = req.headers["x-proxy-secret"] || req.headers["x-proxysecret"] || "";
  if (sent !== PROXY_SECRET) {
    return res.status(401).json({ error: "Unauthorized — wrong proxy secret" });
  }
  next();
}

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/",       (_, res) => res.json({ status: "ok", service: "prochain-proxy", ts: ts() }));
app.get("/health", (_, res) => res.json({ status: "ok", ts: ts(), wsClients: wss.clients.size }));

// ─────────────────────────────────────────────────────────────────────────────
//  REST PROXY
//  All routes: /angel/* → ANGEL_BASE
// ─────────────────────────────────────────────────────────────────────────────

// Map proxy path → Angel One REST URL
const ANGEL_ROUTE_MAP = {
  // Auth
  "POST /angel/login":              `${ANGEL_BASE}/rest/auth/angelbroking/user/v1/loginByPassword`,
  "POST /angel/logout":             `${ANGEL_BASE}/rest/secure/angelbroking/user/v1/logout`,
  "POST /angel/refresh":            `${ANGEL_BASE}/rest/auth/angelbroking/jwt/v1/generateTokens`,

  // Profile / funds
  "GET /angel/profile":             `${ANGEL_BASE}/rest/secure/angelbroking/user/v1/getProfile`,
  "GET /angel/user/profile":        `${ANGEL_BASE}/rest/secure/angelbroking/user/v1/getProfile`,
  "GET /angel/user/getfunds":       `${ANGEL_BASE}/rest/secure/angelbroking/user/v1/getRMS`,
  "GET /angel/margin":              `${ANGEL_BASE}/rest/secure/angelbroking/user/v1/getRMS`,

  // Orders
  "POST /angel/order/place":        `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/placeOrder`,
  "POST /angel/order/modify":       `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/modifyOrder`,
  "POST /angel/order/cancel":       `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/cancelOrder`,
  "GET /angel/order/book":          `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/getOrderBook`,
  "GET /angel/trade/book":          `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/getTradeBook`,
  "GET /angel/position":            `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/getPosition`,
  "POST /angel/position/convert":   `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/convertPosition`,
  "GET /angel/holding":             `${ANGEL_BASE}/rest/secure/angelbroking/portfolio/v1/getHolding`,

  // Market data
  "POST /angel/quote":              `${ANGEL_BASE}/rest/secure/angelbroking/market/v1/quote/`,
  "POST /angel/historical":         `${ANGEL_BASE}/rest/secure/angelbroking/historical/v1/getCandleData`,
  "GET /angel/expiry":              `${ANGEL_BASE}/rest/secure/angelbroking/market/v1/expiry`,
  "POST /angel/optionchain":        `${ANGEL_BASE}/rest/secure/angelbroking/market/v1/optionchain`,
  "POST /angel/search/scrip":       `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/searchScrip`,

  // GTT
  "POST /angel/gtt/create":         `${ANGEL_BASE}/gtt-service/rest/secure/angelbroking/gtt/v1/createRule`,
  "POST /angel/gtt/modify":         `${ANGEL_BASE}/gtt-service/rest/secure/angelbroking/gtt/v1/modifyRule`,
  "POST /angel/gtt/cancel":         `${ANGEL_BASE}/gtt-service/rest/secure/angelbroking/gtt/v1/cancelRule`,
  "GET /angel/gtt/list":            `${ANGEL_BASE}/gtt-service/rest/secure/angelbroking/gtt/v1/ruleList`,
};

// Dynamic routes (path params)
function resolveAngelUrl(method, path) {
  const key = `${method} ${path}`;
  if (ANGEL_ROUTE_MAP[key]) return ANGEL_ROUTE_MAP[key];

  // Dynamic: /angel/order/history/:id  →  getIndividualOrderDetails
  if (method === "GET" && path.match(/^\/angel\/order\/history\//))
    return `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/details/${path.split("/").pop()}`;

  // Dynamic: /angel/order/status/:id
  if (method === "GET" && path.match(/^\/angel\/order\/status\//))
    return `${ANGEL_BASE}/rest/secure/angelbroking/order/v1/details/${path.split("/").pop()}`;

  // Dynamic: /angel/gtt/details/:id
  if (method === "GET" && path.match(/^\/angel\/gtt\/details\//))
    return `${ANGEL_BASE}/gtt-service/rest/secure/angelbroking/gtt/v1/ruleDetails/${path.split("/").pop()}`;

  // Dynamic: /angel/scripmaster/:exchange  →  symbol master CSV
  if (method === "GET" && path.match(/^\/angel\/scripmaster\//)) {
    const exchange = path.split("/").pop().toUpperCase();
    return `${ANGEL_DATA}/OpenAPI_LTP/ltp.php?exch=${exchange}`;
  }

  return null;
}

// ─── Generic REST proxy handler ───────────────────────────────────────────────
async function proxyRest(req, res) {
  const method   = req.method;
  const path     = req.path;
  const angelUrl = resolveAngelUrl(method, path);

  if (!angelUrl) {
    warn(`Unknown route: ${method} ${path}`);
    return res.status(404).json({ error: `Unknown proxy route: ${method} ${path}` });
  }

  // Forward headers from ProChain (Authorization, X-PrivateKey, etc.)
  // Strip hop-by-hop headers
  const HOP_BY_HOP = ["host","connection","transfer-encoding","upgrade","keep-alive","proxy-authorization","proxy-authenticate","te","trailer"];
  const fwdHeaders = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (!HOP_BY_HOP.includes(k.toLowerCase()) && k.toLowerCase() !== "x-proxy-secret") {
      fwdHeaders[k] = v;
    }
  }
  // Ensure content-type set for POST
  if (method === "POST" && !fwdHeaders["content-type"]) {
    fwdHeaders["content-type"] = "application/json";
  }

  try {
    const fetchOpts = {
      method,
      headers: fwdHeaders,
      signal: AbortSignal.timeout(15000),
    };
    if (method === "POST" || method === "PUT" || method === "PATCH") {
      fetchOpts.body = JSON.stringify(req.body);
    }

    log(`→ ${method} ${path}  ↦  ${angelUrl}`);
    const upstream = await fetch(angelUrl, fetchOpts);
    const ct = upstream.headers.get("content-type") || "";

    // Stream response back
    res.status(upstream.status);
    upstream.headers.forEach((v, k) => {
      if (!HOP_BY_HOP.includes(k.toLowerCase())) res.setHeader(k, v);
    });

    if (ct.includes("json")) {
      const data = await upstream.json();
      return res.json(data);
    } else {
      const buf = await upstream.buffer();
      return res.send(buf);
    }
  } catch (e) {
    err(`REST proxy error ${method} ${path}:`, e.message);
    return res.status(502).json({ error: "Proxy upstream error", detail: e.message });
  }
}

// Register REST routes
app.all("/angel/*",  checkSecret, proxyRest);
app.all("/angelbroking/*", checkSecret, async (req, res) => {
  // /angelbroking/user/v1/getRMS → ANGEL_BASE/rest/secure/...
  req.path = req.path.replace("/angelbroking", "");
  proxyRest(req, res);
});

// ─────────────────────────────────────────────────────────────────────────────
//  WEBSOCKET BRIDGE
//  ProChain → proxy /ws → Angel One SmartStream
//
//  Flow:
//   1. ProChain connects to wss://your-proxy.railway.app/ws
//   2. Proxy opens connection to ANGEL_WS_URL
//   3. All frames (text + binary) forwarded both ways
//   4. Proxy handles pings to keep both sides alive
// ─────────────────────────────────────────────────────────────────────────────

const wss = new WebSocket.Server({ server, path: "/ws" });
log(`WebSocket bridge listening on /ws  →  ${ANGEL_WS_URL}`);

wss.on("connection", (clientWs, req) => {
  const ip = req.socket.remoteAddress;
  log(`[WS] Client connected: ${ip}  (total: ${wss.clients.size})`);

  // ── Optional secret check via query param: ws://proxy/ws?secret=xxx
  if (PROXY_SECRET) {
    const url    = new URL(req.url, `http://localhost`);
    const secret = url.searchParams.get("secret") || "";
    if (secret !== PROXY_SECRET) {
      warn(`[WS] Unauthorized client ${ip} — closing`);
      clientWs.close(4001, "Unauthorized");
      return;
    }
  }

  let angelWs     = null;
  let alive       = false;
  let destroyed   = false;
  let pingTimer   = null;
  let reconnTimer = null;
  let reconnCount = 0;
  const MAX_RECONN = 10;

  // ── Connect to Angel One upstream ─────────────────────────────────────────
  function connectAngel() {
    if (destroyed) return;
    if (reconnCount >= MAX_RECONN) {
      warn(`[WS] Max reconnects reached for ${ip}`);
      clientWs.close(1011, "Upstream max reconnects");
      return;
    }

    log(`[WS] Connecting to Angel upstream (attempt ${reconnCount + 1}): ${ANGEL_WS_URL}`);

    angelWs = new WebSocket(ANGEL_WS_URL, {
      headers: {
        "Origin": "https://smartapi.angelbroking.com",
        "User-Agent": "ProChain/1.0",
      },
      rejectUnauthorized: false,  // needed on some Railway environments
    });
    angelWs.binaryType = "nodebuffer";

    angelWs.on("open", () => {
      alive = true;
      reconnCount = 0;
      log(`[WS] Angel upstream connected for ${ip}`);
      // Notify client proxy is ready (matches ProChain's plain-text handler)
      // Don't send — let Angel's own auth response flow through naturally
    });

    // Forward Angel → Client (text + binary)
    angelWs.on("message", (data, isBinary) => {
      if (clientWs.readyState !== WebSocket.OPEN) return;
      try {
        clientWs.send(data, { binary: isBinary });
      } catch (e) {
        warn(`[WS] Error forwarding Angel→Client: ${e.message}`);
      }
    });

    angelWs.on("error", (e) => {
      err(`[WS] Angel upstream error for ${ip}: ${e.message}`);
    });

    angelWs.on("close", (code, reason) => {
      alive = false;
      log(`[WS] Angel upstream closed for ${ip}: ${code} ${reason}`);
      clearInterval(pingTimer);

      // If client still connected → try reconnect with backoff
      if (!destroyed && clientWs.readyState === WebSocket.OPEN) {
        reconnCount++;
        const delay = Math.min(1000 * 2 ** reconnCount, 30000);
        log(`[WS] Reconnecting in ${delay}ms...`);
        reconnTimer = setTimeout(connectAngel, delay);
      }
    });

    // Keepalive pings to Angel
    clearInterval(pingTimer);
    pingTimer = setInterval(() => {
      if (angelWs?.readyState === WebSocket.OPEN) {
        try { angelWs.ping(); } catch(_) {}
      }
    }, 25000);
  }

  // ── Forward Client → Angel ──────────────────────────────────────────────
  clientWs.on("message", (data, isBinary) => {
    if (!angelWs || angelWs.readyState !== WebSocket.OPEN) {
      // Buffer: Angel not ready yet — queue or drop
      warn(`[WS] Angel not ready — dropping frame from ${ip}`);
      return;
    }
    try {
      angelWs.send(data, { binary: isBinary });
    } catch (e) {
      warn(`[WS] Error forwarding Client→Angel: ${e.message}`);
    }
  });

  clientWs.on("close", (code) => {
    log(`[WS] Client ${ip} disconnected: ${code}  (total: ${wss.clients.size})`);
    destroyed = true;
    clearInterval(pingTimer);
    clearTimeout(reconnTimer);
    if (angelWs) {
      try { angelWs.close(); } catch(_) {}
      angelWs = null;
    }
  });

  clientWs.on("error", (e) => {
    err(`[WS] Client ${ip} error: ${e.message}`);
  });

  // ── Start ─────────────────────────────────────────────────────────────────
  connectAngel();
});

// ─── Start HTTP server ────────────────────────────────────────────────────────
server.listen(PORT, () => {
  log(`ProChain Proxy running on port ${PORT}`);
  log(`REST: /angel/*  →  Angel One REST API`);
  log(`WS:   /ws       →  Angel SmartStream (${ANGEL_WS_URL})`);
  if (PROXY_SECRET) log(`Secret auth: ENABLED`);
  else              log(`Secret auth: DISABLED (set PROXY_SECRET to enable)`);
});

// ─── Graceful shutdown ────────────────────────────────────────────────────────
process.on("SIGTERM", () => {
  log("SIGTERM — shutting down gracefully");
  server.close(() => { log("HTTP server closed"); process.exit(0); });
  wss.close();
});
process.on("SIGINT", () => {
  log("SIGINT — shutting down");
  process.exit(0);
});
